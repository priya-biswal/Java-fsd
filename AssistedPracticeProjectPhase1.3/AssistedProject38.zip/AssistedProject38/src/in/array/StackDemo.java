package in.array;
import java.io.*;
import java.util.*;
 import java.util.*;
class StackDemo {
    public static void main(String[] args)
    {
        Stack stack1 = new Stack();
        Stack<String> stack2 = new Stack<String>();
 
        stack1.push("4");
        stack1.push("11");
        stack1.push("23");
 
        stack2.push("stack");
        stack2.push("demo");
        stack2.push("practice");
        
        System.out.println(stack1);
        System.out.println(stack2);
        System.out.println("Popped element: "+ stack1.pop());
       System.out.println("Popped element: "+ stack2.pop());
         System.out.println("Stack after pop operation "+ stack1 + stack2);
        }
    }
