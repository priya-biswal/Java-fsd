package in.array;
public class ArrayExample {
	public void sortArr(int arr[])  
	{  
	int size = arr.length;  
	  
	for(int i = 0; i < size; i++)  
	{  
	int temp = i;  
	for(int j = i + 1; j < size; j++)  
	{  
	if(arr[temp] > arr[j])  
	{  
	temp = j;  
	  }  	  	  	  
	}  	  	  
	if(temp != i)  
	{  
	int t = arr[i];  
	arr[i] = arr[temp];  
	arr[temp] = t;   
	   }  
	  }  
	}   
	public int findKthSmallest(int arr[], int k)  
	{  
	sortArr(arr);  	
	return arr[k - 1];  
	}   
	public static void main(String argvs[])  
	{   
	ArrayExample obj = new ArrayExample();  
	  
	int arr[] = {5, 33, 8, 19, 10, 56, 41, 7};  	  
	int size = arr.length;  
	int k = 4;    
	System.out.println("For the array: ");  
	for(int i = 0; i < size; i++)  
	{  
	System.out.print(arr[i] + " ");  
	   }
	int ele= obj.findKthSmallest(arr, k);  
	  
	System.out.println();  
	System.out.println("The " + k + "th smallest element of the array is: " + ele);
	  }
	}
