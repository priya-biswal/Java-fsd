package com.practice;

import java.sql.*;

public class IndexRow {
	public static void main(String args[]){ 
		try {
			//register driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conObj=DriverManager.getConnection("jdbc:mysql://localhost:3306/mphasis_db","root","suvashree#1234");
			
			Statement st=conObj.createStatement();
			st.executeUpdate("insert into student(rollno,sname,course,fees) values(3,'anikit','ai',26000.00)");
			System.out.println("row is added....");
		}
		catch(Exception ex){
			System.out.println(ex);
		}
		
	}}


