package Com.practice;
import java.sql.*;

public class Insert {
public static void main(String arg[]) throws Exception {
	String id="id1";
	String pwd="pwd1";
	String fullnmae="SuvashreeBiswal";
	String email="suvashree@gmail.com";
	
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");//load and register
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mphasis_db","root","suvashree#1234");
	Statement stmt=con.createStatement();
	String q1="insert into userid values('"+id+"','"+pwd+"','"+fullnmae+"','"+email+"' )";
	int x=stmt.executeUpdate(q1);
	
	if(x>0) {
		System.out.println("insert successfully");
	}
	else {
		System.out.println("  insertion failed");
	}
	con.close();
	}
	catch(Exception ex) {
		System.out.println(ex);
	}
}
}
