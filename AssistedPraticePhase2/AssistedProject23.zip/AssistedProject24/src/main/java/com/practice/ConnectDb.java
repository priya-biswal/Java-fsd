package com.practice;

import java.sql.*;

public class ConnectDb {
public static void main(String arg[]) throws Exception{
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");//load and register
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mphasis_db","root","suvashree#1234");
	if(con!=null)	{
		System.out.println("connected");
	}
	else {
		System.out.println(" not connected");
	}
		
	}
	catch(Exception ex){
		System.out.println(ex);
	}
}}
