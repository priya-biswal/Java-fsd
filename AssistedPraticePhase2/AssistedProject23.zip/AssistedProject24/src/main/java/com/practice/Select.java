package com.practice;
import java.sql.*;
public class Select {
public static void main(String arg[]) {
	String id="id1";
	String pwd="pwd1";
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");//load and register
    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mphasis_db","root","suvashree#1234");
    	Statement stmt = con.createStatement();
        
        // SELECT query
        String q1 = "select * from userid WHERE id = '" + id +
                                "' AND pwd = '" + pwd + "'";
        ResultSet rs = stmt.executeQuery(q1);
        if (rs.next())
        {
            System.out.println("User-Id : " + rs.getString(1));
            System.out.println("Full Name :" + rs.getString(3));
            System.out.println("E-mail :" + rs.getString(4));
        }
        else
        {
            System.out.println("No such user id is already registered");
        }
        con.close();
    }
    catch(Exception e)
    {
        System.out.println(e);
    }
}}

