package com.practice;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

//import java.sql.;
public class Jdbc1 {
public static void main(String arg[]) throws Exception {
	
		Class.forName("com.mysql.jdbc.Driver");//load and register
		Connection com=DriverManager.getConnection("jdbc:mysql://localhost:3306/hibernate","root","suvashree#1234");
		PreparedStatement ps=com.prepareStatement("select * from student");
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			String name1=rs.getString("id");
			System.out.println(name1);			
		}
	}
}

