package com.Fliter;

	import java.io.IOException;
	import javax.servlet.Filter;
	import javax.servlet.FilterChain;
	import javax.servlet.FilterConfig;
	import javax.servlet.ServletException;
	import javax.servlet.ServletRequest;
	import javax.servlet.ServletResponse;
	import javax.servlet.annotation.WebFilter;

	@WebFilter("/HelloServlet") // Filter applied to the HelloServlet
	public class LoggingFilter implements Filter {

	    public void init(FilterConfig filterConfig) throws ServletException {
	        // Initialization code (if needed)
	    }

	    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
	            throws IOException, ServletException {
	        // Log information about the incoming request
	        System.out.println("Request received at " + new java.util.Date());

	        // Continue the request/response chain
	        chain.doFilter(request, response);

	        // Log information about the response (if needed)
	    }

	    public void destroy() {
	        // Cleanup code (if needed)
	    }
	}

