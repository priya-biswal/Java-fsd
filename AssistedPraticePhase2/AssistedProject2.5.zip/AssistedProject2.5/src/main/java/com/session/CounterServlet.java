package com.session;

	import java.io.IOException;
	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.Cookie;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.servlet.http.HttpSession;

	@WebServlet("/CounterServlet")
	public class CounterServlet extends HttpServlet {
	    private static final long serialVersionUID = 1L;

	    protected void doGet(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        HttpSession session = request.getSession();
	        Integer visitCount = (Integer) session.getAttribute("visitCount");

	        if (visitCount == null) {
	            visitCount = 1;
	        } else {
	            visitCount++;
	        }

	        session.setAttribute("visitCount", visitCount);

	        Cookie visitCountCookie = new Cookie("visitCount", visitCount.toString());
	        visitCountCookie.setMaxAge(3600); // Cookie expires in 1 hour
	        response.addCookie(visitCountCookie);

	        response.setContentType("text/html");
	        response.getWriter().println("<html><head><title>Session Tracking with Cookies</title></head><body>");
	        response.getWriter().println("<h1>Session Tracking with Cookies</h1>");
	        response.getWriter().println("<p>Number of Visits: " + visitCount + "</p>");
	        response.getWriter().println("</body></html>");
	    }
	}

