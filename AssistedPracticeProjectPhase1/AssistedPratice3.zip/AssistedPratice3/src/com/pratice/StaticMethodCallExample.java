package com.pratice;

public class StaticMethodCallExample {
	
	public static void main(String args[])   
	{  
	int a;  
  
	a=Math.min(23,98);  
	
	System.out.println("Minimum number is: " + a);  
	}  
	}

