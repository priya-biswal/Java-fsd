package com.pratice;
public class PredefinedMethodCallExample  
{  
public static void main(String[] args)   
{  
int a;      
Object obj=new Object();      
a=obj.hashCode();  
System.out.println("Hash Code of the object is: "+a);  
}  
}