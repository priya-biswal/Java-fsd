package com.pratice;
abstract class AbstractMethodExample   
{ 
abstract void show();    
}    
public class AbstractMethodCalling extends AbstractMethodExample  
{      
void show()  
{  
System.out.println("The abstract method called.");  
}    
public static void main(String args[])  
{    
AbstractMethodExample obj = new AbstractMethodCalling();    
  
obj.show();    
}    
}