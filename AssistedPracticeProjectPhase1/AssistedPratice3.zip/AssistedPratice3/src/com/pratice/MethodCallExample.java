package com.pratice;
public class MethodCallExample  
{  
//user-defined static method  
static void showMessage()   
{  
System.out.println("The static method invoked.");  
}  
void displayMessage()   
{  
System.out.println("Non-static method invoked.");  
}  
public static void main(String[] args)   
{ 
showMessage(); 

MethodCallExample me=new MethodCallExample();  

me.displayMessage(); 
}  
}