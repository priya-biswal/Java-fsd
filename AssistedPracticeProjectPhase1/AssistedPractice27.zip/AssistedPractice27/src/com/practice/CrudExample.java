package com.practice;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class CrudExample {
	
	public static void main(String[] args) {
		
		        String fileName = "items.txt";

		        // Create a sample list of items
		        List<String> items = new ArrayList<>();
		        items.add("Item 1");
		        items.add("Item 2");
		        items.add("Item 3");
		       
		        createFile(fileName, items);
		        List<String> readItems = readFile(fileName);
		        System.out.println("Read items from file: " + readItems);
		        
		        updateFile(fileName, 1, "Updated Item 2");
		        readItems = readFile(fileName);
		        System.out.println("Updated items: " + readItems);
		        
		        deleteFromFile(fileName, 0);
		        readItems = readFile(fileName);
		        System.out.println("After deletion: " + readItems);
		    }

		    
		    private static void createFile(String fileName, List<String> items) {
		        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
		            for (String item : items) {
		                writer.println(item);
		            }
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
		    }
		    
		    private static List<String> readFile(String fileName) {
		        List<String> items = new ArrayList<>();
		        try (Scanner scanner = new Scanner(new File(fileName))) {
		            while (scanner.hasNextLine()) {
		                items.add(scanner.nextLine());
		            }
		        } catch (FileNotFoundException e) {
		            e.printStackTrace();
		        }
		        return items;
		    }
		   
		    private static void updateFile(String fileName, int lineIndex, String updatedItem) {
		        List<String> items = readFile(fileName);
		        if (lineIndex >= 0 && lineIndex < items.size()) {
		            items.set(lineIndex, updatedItem);
		            try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
		                for (String item : items) {
		                    writer.println(item);
		                }
		            } catch (IOException e) {
		                e.printStackTrace();
		            }
		        }
		    }
		   
		    private static void deleteFromFile(String fileName, int lineIndex) {
		        List<String> items = readFile(fileName);
		        if (lineIndex >= 0 && lineIndex < items.size()) {
		            items.remove(lineIndex);
		            try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
		                for (String item : items) {
		                    writer.println(item);
		                }
		            } catch (IOException e) {
		                e.printStackTrace();
		            }
		        }
		   }		
	}


