package com.assistedpratice;
class A 
{ 
void display() 
    { 
        System.out.println("hello java"); 
    } 
} 

