package p1;

public class A {
	protected void display() 
    { 
        System.out.println("suvashreebiswal"); 
    }}
