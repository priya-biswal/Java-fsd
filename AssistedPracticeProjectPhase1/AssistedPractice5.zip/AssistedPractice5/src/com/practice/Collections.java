package com.practice;
import java.util.*;
public class Collections {

	    public static void main(String args[])
	    {
	        LinkedList<String> al = new LinkedList<String>();
	 
	        al.add("This");
	        al.add("is");
	        al.add("linkedist");
	        al.add("collection");
	 
	        Iterator<String> itr = al.iterator();
	        while (itr.hasNext()) {
	            System.out.println(itr.next());
	        }
}}
