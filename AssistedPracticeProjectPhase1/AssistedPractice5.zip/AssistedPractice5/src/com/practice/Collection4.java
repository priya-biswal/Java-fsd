package com.practice;
import java.util.*;
public class Collection4 {
	
	    public static void main(String[] args)
	    {
	        Map<Integer, String> map = new HashMap<>();
	 
	        map.put(1, "This");
	        map.put(2, "is");
	        map.put(3, "map");
	        map.put(4, "interface");
	 
	        Set set = map.entrySet();
	 
	        Iterator itr = set.iterator();
	 
	        while (itr.hasNext()) {
	           
	            Map.Entry entry = (Map.Entry)itr.next();
	 
	            System.out.println(entry.getKey() + " "
	                               + entry.getValue());
	        }
}}
