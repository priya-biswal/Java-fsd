package com.practice;
import java.util.*;
public class Collection3 {
	
	    public static void main(String args[])
	    {	   
	        Stack<String> stack = new Stack<String>();
	 
	        stack.push("This");
	        stack.push("Is");
	        stack.push("Stack");
	        stack.push("collection");
	      
	        stack.pop();
	 
	        Iterator<String> itr = stack.iterator();
	 
	        while (itr.hasNext()) {
	 
	            System.out.println(itr.next());
	        }
	    }
}
