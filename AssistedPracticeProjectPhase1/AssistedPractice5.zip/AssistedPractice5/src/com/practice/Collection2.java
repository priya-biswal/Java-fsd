package com.practice;
import java.util.*;
public class Collection2 {
	public static void main(String args[])
    {
        ArrayList<String> list = new ArrayList<String>();
        list.add("This");
        list.add("Is");
        list.add("ArrayList");
        list.add("collection");
 
        Iterator<String> itr = list.iterator();
        while (itr.hasNext()) {
            System.out.println(itr.next());
        }
    }
	
}
