package com.practice;

public class MyRun implements Runnable{
	public void run(){  
		System.out.println("thread is running...");  
		}  		  
		public static void main(String args[]){  
		MyRun m1=new MyRun();  
		Thread t1 =new Thread(m1);    
		t1.start();  
		 }  
}
