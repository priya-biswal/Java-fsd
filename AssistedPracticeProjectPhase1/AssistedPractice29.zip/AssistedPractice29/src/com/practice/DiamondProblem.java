package com.practice;
interface Animal {
    void speak();
}

class Dog implements Animal {
    @Override
    public void speak() {
        System.out.println("Dog barks.");
    }
}

class Cat implements Animal {
    @Override
    public void speak() {
        System.out.println("Cat meows.");
    }
}

class Pet implements Animal {
    private Dog dog;
    private Cat cat;

    public Pet() {
        dog = new Dog();
        cat = new Cat();
    }

    @Override
    public void speak() {
        dog.speak();
        cat.speak();
    }

    public class DiamondProblem{
    public static void main(String[] args) {
        Pet myPet = new Pet();
        myPet.speak(); 
    }
  }
}


