package com.practice;

public class ConstructorTypeDemo2 {
int id ;
String name;  
//creating a parameterized constructor  
ConstructorTypeDemo2(int i,String n){  
id = i;  
name = n;  
}  
void display(){System.out.println(id+" "+name);}  

public static void main(String args[]){  
 
	ConstructorTypeDemo2 s1 = new ConstructorTypeDemo2(111,"Karan");  
	
	ConstructorTypeDemo2 s2 = new ConstructorTypeDemo2(222,"Aryan");  

s1.display();  

s2.display();  
}  
}
