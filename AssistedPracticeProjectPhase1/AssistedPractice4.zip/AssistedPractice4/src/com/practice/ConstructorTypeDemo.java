package com.practice;
public class ConstructorTypeDemo{
int id; 
String name;  
//method to display the value of id and name  
void display(){System.out.println(id+" "+name);}  

public static void main(String args[]){  
//creating objects  
	ConstructorTypeDemo s1=new ConstructorTypeDemo();  
	ConstructorTypeDemo s2=new ConstructorTypeDemo();  
//displaying values of the object  
s1.display();  
s2.display();  
}
		
}


