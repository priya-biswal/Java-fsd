package com.taxcalculation;
public class Vehicle{
	private String registrationNumber;
    private String brand;
    private double purchaseCost;
    private double maxVelocity;
    private int capacity;
    private int vehicleChoice; 

    public Vehicle(String registrationNumber, String brand, double purchaseCost, double maxVelocity, int capacity, int vehicleChoice) {
        this.registrationNumber = registrationNumber;
        this.brand = brand;
        this.purchaseCost = purchaseCost;
        this.maxVelocity = maxVelocity;
        this.capacity = capacity;
        this.vehicleChoice = vehicleChoice;
    }

    public double calculateVehicleTax() {
        double tax = 0.0;
        double purchaseTaxFactor = 0.0;

        switch (vehicleChoice) {
            case 1: 
                purchaseTaxFactor = 0.10;
                break;
            case 2: 
                purchaseTaxFactor = 0.11;
                break;
            case 3: // CNG/LPG
                purchaseTaxFactor = 0.12;
                break;
        }

        tax = maxVelocity + capacity + (purchaseTaxFactor * purchaseCost);

        return tax;
    }

    @Override
    public String toString() {
        return "Registration Number: " + registrationNumber +
               "\nBrand: " + brand +
               "\nPurchase Cost: " + purchaseCost +
               "\nMax Velocity: " + maxVelocity +
               "\nPassenger Count: " + capacity +
               "\nVehicle Type: " + (vehicleChoice == 1 ? "Petrol" : (vehicleChoice == 2 ? "Diesel" : "CNG/LPG"));
    }
    }

