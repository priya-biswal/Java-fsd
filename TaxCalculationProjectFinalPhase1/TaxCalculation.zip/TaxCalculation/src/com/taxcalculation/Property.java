package com.taxcalculation;
import java.util.Scanner;
public class Property {
	private double baseValue;
    private double builtUpArea;
    private double ageOfLand;
    private boolean inCity;
    private int propertyID;

    public Property(double baseValue, double builtUpArea, double ageOfLand, boolean inCity) {
        this.baseValue = baseValue;
        this.builtUpArea = builtUpArea;
        this.ageOfLand = ageOfLand;
        this.inCity = inCity;
       
    }
   

    public double calculatePropertyTax() {
        double tax = 0.0;
        double ageFactor = 1.0;

        // Adjust age factor based on the age of construction
        if (ageOfLand < 5) {
            ageFactor = 0.8;
        } else if (ageOfLand >= 5 && ageOfLand < 10) {
            ageFactor = 0.7;
        } else {
            ageFactor = 0.6;
        }

        // Calculate property tax based on location (in-city or not)
        if (inCity) {
            tax = (builtUpArea * ageFactor * baseValue) + (0.5 * builtUpArea);
        } else {
            tax = builtUpArea * ageFactor * baseValue;
        }

        return tax;
    }
  
    
    @Override
    public String toString() {
        return  "PROPERTY ID: "+propertyID+
        		"BUILT-UP AREA: " + builtUpArea +
               "\nBASE PRICE: " + baseValue +
               "\nAGE(YEARS): " + ageOfLand +
               "\nIN CITY: " + (inCity ? "Yes" : "No") +
               "\nPROPERTY TAX: " + calculatePropertyTax();
    }
}
    
	


