package com.taxcalculation;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
public class TaxCalculatorApp {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.println("*****************************************");	        
	        System.out.println(" || WELCOME TO TAX CALCULATION APP || ");
	        System.out.println("*****************************************");	
	        System.out.println("PLEASE LOGIN TO CONTINUE");
	       
	        System.out.print("USERNAME: ");
	        String inputUsername = scanner.nextLine();
	        System.out.print("PASSWORD: ");
	        String inputPassword = scanner.nextLine();
	       
	        if (authenticate(inputUsername,inputPassword)) {
	            System.out.println("Login successful.\n");
	            List<Property> properties = new ArrayList<>();
	            List<Vehicle> vehicles = new ArrayList<>();
	            
	            while (true) {
	            
	                System.out.println("1. PROPERTY TAX");
	                System.out.println("2. VEHICLE TAX");
	                System.out.println("3. TOTAL");
	                System.out.println("4. EXIT");
                    System.out.println("ENTER UR CHOICE");
	                int mainchoice = scanner.nextInt();	              
					scanner.nextLine();
	                switch (mainchoice) {
	                    case 1:
	                    	//property choice	                
	                    	while (true) {
	                        System.out.println("1. ADD PROPERTY DETAILS");
	                        
	                        System.out.println("2. CALCULATE PROPERTY TASK");
	                        System.out.println("3. DISPLAY ALL PROPERTIES");
	                        System.out.println("4. BACK TO MAIN MENU");
	                        System.out.println("ENTER UR CHOICE");
	                       int propertyChoice=scanner.nextInt();
	                       scanner.nextLine();
	                       switch(propertyChoice) {
	                       case 1:
	                    	   System.out.println("ENTER THE PROPERTY DETAILS: ");
	                        System.out.print("Base Value of Land: ");
	                        double baseValue = scanner.nextDouble();
	                    System.out.println("Enter the bulit-up area: ");
	                        double builtUpArea = scanner.nextDouble();
	                        System.out.print("Age of Land (in years): ");
	                        double ageOfLand = scanner.nextDouble();
	                        System.out.print("Is the property in the city? (Y/N): ");
	                        String inCityInput = scanner.next();
	                        boolean inCity = inCityInput.equalsIgnoreCase("Y");

	                        // Create a Property object with the entered details
	                        Property property = new Property(baseValue, builtUpArea, ageOfLand, inCity);
                           properties.add(property);
                           System.out.println("property added sucessfuly");
	                       break;
	                       case 2:
	                    	   
	                        System.out.println("\n CALCULATE PROPERTY TASK");	                      
	                        System.out.println("*******--------------********");
	                        for (Property prop : properties) {
                                System.out.println(prop);
                                System.out.println("Property Tax: " + prop.calculatePropertyTax());
                                System.out.println("*******--------------********");
                                }
                            break;
                            
                        case 3:
                        	System.out.println("\n :");
                            if (properties.isEmpty()) {
                                System.out.println("No properties available.");
                            } else {
                                for (int i = 0; i < properties.size(); i++) {
                                    System.out.println("Property ID: " + i);
                                    System.out.println(properties.get(i)); // Display property details
                                    System.out.println("Property Tax: " + properties.get(i).calculatePropertyTax()); // Display property tax
                                    System.out.println();
                                }
                            }
                            break;

                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }

                    if (propertyChoice == 2) {
                        break; // Exit the property sub-menu
                    }
                }
                break;

            case 2:
                // Vehicle Options
                while (true) {
                    System.out.println("\nVehicle Menu:");
                    System.out.println("1. Add Vehicle");
                    System.out.println("2. Back to Main Menu");
                    System.out.print("Enter your choice: ");
                    int vehicleChoice = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    switch (vehicleChoice) {
                        case 1:
                            System.out.print("Enter Registration Number: ");
                            String registrationNumber = scanner.next();
                            System.out.print("Enter Brand: ");
                            String brand = scanner.next();
                            System.out.print("Enter Purchase Cost: ");
                            double purchaseCost = scanner.nextDouble();
                            System.out.print("Enter Max Velocity: ");
                            double maxVelocity = scanner.nextDouble();
                            System.out.print("Enter Capacity: ");
                            int capacity = scanner.nextInt();

                            Vehicle vehicle = new Vehicle(registrationNumber, brand, purchaseCost, maxVelocity, capacity, vehicleChoice);
                            vehicles.add(vehicle);
                            System.out.println("Vehicle added successfully!");
                            break;

                        case 2:
                            // Return to the main menu
                            break;

                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }

                    if (vehicleChoice == 2) {
                        break; // Exit the vehicle sub-menu
                    }
                }
                break;

            case 3:
                // View and Calculate Taxes
                // Include code to display property and vehicle details and calculate taxes (similar to previous example)
            	System.out.println("\nProperty Details and Taxes:");
                for (Property prop : properties) {
                    System.out.println(prop);
                    System.out.println("Property Tax: " + prop.calculatePropertyTax());
                    System.out.println();
                }

                System.out.println("\nVehicle Details and Taxes:");
                for (Vehicle veh : vehicles) {
                    System.out.println(veh);
                    System.out.println("Vehicle Tax: " + veh.calculateVehicleTax());
                    System.out.println();
                }
                break;
            	

            case 4:
                System.out.println("Exiting the application.GOOD BYE....!!");
                scanner.close();
                System.exit(0);

            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
    } else {
        System.out.println("Authentication failed. Exiting the application.");
    }
    scanner.close();
}
	    private static boolean authenticate(String username, String password) {
            return username.equals("suvashree") && password.equals("1234");
        }
}