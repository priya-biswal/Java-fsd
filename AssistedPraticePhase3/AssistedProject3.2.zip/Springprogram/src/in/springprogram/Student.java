package in.springprogram;


	public class Student {
	private int id;
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", email=" + email + ", rollno=" + rollno + "]";
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int id, String name, String email, int rollno) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.rollno = rollno;
	}
	private String name;
	private String email;
	private int rollno;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public void display() {
		// TODO Auto-generated method stub
		
	}
	}


