package com.spring.jdbc.SpringJdbc;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
public class App 
{
    public static void main( String[] args )
    {
      System.out.println( "Hello World!" );
      ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("com/spring/jdbc/SpringJdbc/config.xml");
      JdbcTemplate template=context.getBean("jdbcTemplate",JdbcTemplate.class);
      String query="insert into user(uid,fname,lname,email)values(?,?,?,?)";
    int result=template.update(query,112,"ankit","patel","ankit@gmail.com");
      System.out.println("number of record inserted...."+result);
    }
}
 