package com.simplilearn.fitnessclubautomation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FitnessclubautomationApplicationTests {

	@Test
	void contextLoads() {
	}

}
