package com.project.fitnessclubautomation.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.project.fitnessclubautomation.model.Trainer;

@Repository
public interface TrainerRepository extends CrudRepository<Trainer, Long> {
}
