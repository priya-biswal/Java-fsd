package coms.RestApiWithJunit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiWithJunitApplicationTests {

	@Test
	void contextLoads() {
	}

}
