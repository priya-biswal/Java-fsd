package coms.RestApiWithJunit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import coms.RestApiWithJunit.entities.Employee;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


public class EmpTesting extends RestApiWithJunitApplicationTests {

	@Autowired
	private WebApplicationContext webApplicationContext;

	private MockMvc mockMvc;

	@BeforeEach // as same as @Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}
	
	@Test
	public void testEmployee() throws Exception {
			
		mockMvc.perform(get("/emps"))
		.andExpect(status().isOk())
				.andExpect(content().contentType("application/json"))
				.andExpect(jsonPath("$.empno").value("1001"))
				.andExpect(jsonPath("$.ename").value("Jagan"))
				.andExpect(jsonPath("$.job").value("Manager"))
				.andExpect(jsonPath("$.salary").value(15000.00));
	}
	
	@Test
	public void testAddEmployee() throws Exception {
		
		Employee emp = new Employee();
		emp.setEmpno(1002);
		emp.setEname("Sahasra");
		emp.setJob("HR-Manager");
		emp.setSalary(25000.00f);
		
		System.out.println(emp.getEname());
		
		mockMvc.perform(post("/emps"))
		.andExpect(status().isBadRequest())
				.andExpect(content().contentType("application/json"))
				//.andExpect(jsonPath("$.result").value("Emp Added"));
				.andExpect(jsonPath("$.empno").value(emp.getEmpno()))
				.andExpect(jsonPath("$.ename").value(emp.getEname()))
				.andExpect(jsonPath("$.job").value(emp.getJob()))
				.andExpect(jsonPath("$.salary").value(emp.getSalary()));
	}
}
