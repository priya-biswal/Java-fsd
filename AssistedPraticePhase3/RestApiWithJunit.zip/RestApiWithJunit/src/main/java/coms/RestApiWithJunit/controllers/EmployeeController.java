package coms.RestApiWithJunit.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import coms.RestApiWithJunit.entities.Employee;

@RestController
public class EmployeeController {

	
	
	@GetMapping("/emps")
	public ResponseEntity<Object> empall()
	{
		Employee emp = new Employee();
		emp.setEmpno(1001);
		emp.setEname("Jagan");
		emp.setJob("Manager");
		emp.setSalary(15000.00f);
		
		return new ResponseEntity<Object>(emp, HttpStatus.OK);
	}
	
	@PostMapping("/emps")
	public ResponseEntity<Object> AddEmployee(@RequestBody Employee emp)
	{
		List<Employee>  emplist = new ArrayList<Employee>();
		emplist.add(emp);
		
		System.out.println(emp.getEmpno());
		System.out.println(emp.getEname());
		System.out.println(emp.getJob());
		System.out.println(emp.getSalary());
		String result = "Emp Added";
		return new ResponseEntity<Object>(result, HttpStatus.OK);
	}
}
