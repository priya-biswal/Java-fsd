package coms.RestApiWithJunit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiWithJunitApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiWithJunitApplication.class, args);
		System.out.println("Service Started....");
	}

}
