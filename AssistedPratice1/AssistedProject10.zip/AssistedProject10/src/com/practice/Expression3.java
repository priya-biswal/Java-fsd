package com.practice;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
  
public class Expression3 {
	
	    private static String REGEX = "?[^a-zA-Z0-9]";
	    private static String MSG = "It is/ a ? Pattern syntax Exception Class!!";
	    private static String REPLACE = " ";
	  
	    public static void main(String[] args)
	    {
	  
	        try {
	            
	            Pattern pattern = Pattern.compile(REGEX);	  
	            
	            Matcher matcher = pattern.matcher(MSG);
	  	            
	            MSG = matcher.replaceAll(REPLACE);
	  
	        }
	        catch (PatternSyntaxException pse) {
	            System.out.println("PatternSyntaxException: ");
	            System.out.println("Description: "
	                               + pse.getDescription());
	            System.out.println("Index: " + pse.getIndex());
	            System.out.println("Message: "
	                               + pse.getMessage());
	            System.out.println("Pattern: "+ pse.getPattern());
	            System.exit(0);
	        }
	  
	        System.out.println("Output: " + MSG);
	    }
}
