package com.practice;
import java.util.regex.*;
public class RegularExpessions {
		 		//FOR PATTERN CLASS DEMONSTRATE 	    
	    public static void main(String[] args)
	    {
	        // Creating a pattern
	        Pattern pattern = Pattern.compile("pattern class");
	 
	        // Creating a matcher for the input
	        Matcher matcher = pattern.matcher("pattern class");
	 
	        // Checking for a match
	        // using matches() method
	        boolean letsCheck = matcher.matches();
	 
	        // Display message only
	        System.out.println("check whether the pattern matches or not:");
	 
	        // Condition check whether pattern is matched or not
	        if (letsCheck)
	 
	            // Matched
	            System.out.println("Pattern Matched");
	        else
	 
	            // Not matched
	            System.out.println("Pattern does not match");
	    }}
	   