package com.practice;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Expression2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 final String REGEX = "\\bsuva\\b";
		 final   String INPUT = "suva suva suva suvashree suvas";	   
		    {
		        Pattern pat = Pattern.compile(REGEX);	        		       
		        Matcher mat = pat.matcher(INPUT);		        		       
		        int count = 0;		        
		        while (mat.find()) {
		            count++;
		            System.out.println("Match number " + count);
		            System.out.println("start(): " + mat.start());
		            System.out.println("end(): " + mat.end());
		        }
		    }		
	    }
    }
