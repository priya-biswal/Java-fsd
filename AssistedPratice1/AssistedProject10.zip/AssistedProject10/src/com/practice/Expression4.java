package com.practice;
import java.io.*;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
 
public class Expression4 {
	
	    private static final String regularExpression = "(.*)(\\d+)(.*)";

	    private static final String input = "Hello World!, 1122343, these are the numbers.";
	 
	    public static void main(String[] args)
	    {	        
	        Pattern myPattern = Pattern.compile(regularExpression);	 
	        
	        Matcher myMatcher = myPattern.matcher(input);
	 
	        if (myMatcher.find()) {	 
	        	
	            MatchResult myResult = myMatcher.toMatchResult(); 
	            
	            System.out.println("Starting index of the match: " + myResult.start());
	        }
	    }
	}

