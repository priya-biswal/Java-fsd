package com.practice;

public class OuterClass {
	
	    private int outerField = 10;
	  
	    public class InnerClass {
	    	
	        public void displayOuterField() {
	        	
	            System.out.println("Value of outerField from InnerClass: " + outerField);
	        }
	    }
	    public static void main(String[] args) {
	      
	        OuterClass outerObj = new OuterClass();

	        OuterClass.InnerClass innerObj = outerObj.new InnerClass();

	        innerObj.displayOuterField();
	    }
	}

